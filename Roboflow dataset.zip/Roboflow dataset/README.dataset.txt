# continuous_fire > original_raw-images
https://universe.roboflow.com/-jwzpw/continuous_fire

Provided by a Roboflow user
License: CC BY 4.0

